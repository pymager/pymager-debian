#!/bin/sh
sudo python setup.py develop -d /usr/local/lib/python2.5/site-packages
