#!/usr/bin/env python
from migrate.versioning.shell import main

main(repository='pymager_db')
